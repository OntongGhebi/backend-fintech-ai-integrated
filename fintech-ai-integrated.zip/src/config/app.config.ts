import { registerAs } from '@nestjs/config';

export default registerAs('app', () => ({
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT ?? 3000),
  apiPrefix: process.env.API_PREFIX || 'api/v1',
  timezone: process.env.APP_TIMEZONE ?? 'Asia/Jakarta',
  frontendUrl: process.env.FRONTEND_URL,
}));
